﻿using Capgemini.CMS.Entities.Models;
using Capgemini.CMS.Entities.ViewModels;
using Capgemini.CMS.Repositories.CargoOrders;
using Capgemini.CMS.Repositories.Products;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Capgemini.CMS.WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CargoOrderApiController : ControllerBase
    {
        private readonly ICargoOrderRepository cargoOrderRepository;

        public CargoOrderApiController(ICargoOrderRepository cargoOrderRepository)
        {
            this.cargoOrderRepository = cargoOrderRepository;
        }

        // GET: api/<CargoOrderApiController>
        [HttpGet]
        public IEnumerable<CargoOrder> Get()
        {
            var list = cargoOrderRepository.Get();
            return list;
        }

        // GET api/<CargoOrderApiController>/5
        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            var order = cargoOrderRepository.Get(id);
            if (order == null)
            {
                return NotFound();
            }
            return Ok(order);
        }

        // POST api/<CargoOrderApiController>
        [HttpPost]
        public IActionResult Post([FromBody] CargoOrderViewModel viewModel)
        {
            //repo.Add

            if(cargoOrderRepository.AddCart(viewModel))
            {
                return Created("created", viewModel);
            }
            else
            return StatusCode(StatusCodes.Status500InternalServerError);

        }

        // PUT api/<CargoOrderApiController>/5
        [HttpPut("{id}")]
        public ActionResult Put(int id, [FromBody] CargoOrder order)
        {
            if (id != order.Id)
            {
                return BadRequest("id is not match");
            }
            else
            {
                //ssv
                if (ModelState.IsValid)
                {
                    //update
                    if (cargoOrderRepository.Update(order))
                    {
                        return Ok();
                    }
                    else
                    {
                        return StatusCode(StatusCodes.Status500InternalServerError);
                    }
                }
                else
                {
                    return BadRequest(ModelState);
                }
            }
        }

        // DELETE api/<CargoOrderApiController>/5
        [HttpDelete("{id}")]
        public ActionResult Delete(int id)
        {
            var order = cargoOrderRepository.Get(id);
            if (cargoOrderRepository.Delete(order))
            {
                return Ok();
            }
            return StatusCode(StatusCodes.Status404NotFound);
        }
    }
}
