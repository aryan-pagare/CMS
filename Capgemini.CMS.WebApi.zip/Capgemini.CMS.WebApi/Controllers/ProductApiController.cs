﻿using Capgemini.CMS.Entities.Models;
using Capgemini.CMS.Repositories.Products;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Capgemini.CMS.WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductApiController : ControllerBase
    {
        private readonly IProductRepository productRepository;

        public ProductApiController(IProductRepository productRepository)
        {
            this.productRepository = productRepository;
        }

        // GET: api/<ProductApiController>
        [HttpGet]
        public IEnumerable<Product> Get()
        {
            var list = productRepository.Get();
            return list;    
        }

        // GET api/<ProductApiController>/5
        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            var product = productRepository.Get(id);
            if (product == null)
            {
                return NotFound();
            }
            return Ok(product);
        }

        // POST api/<ProductApiController>
        [HttpPost]
        public IActionResult Post([FromBody] Product product)
        {
            //ssv
            if (ModelState.IsValid)
            {
                //Repository methods call
                if (productRepository.Add(product))
                {
                    return Created("product", product);
                }
                else
                {
                    return StatusCode(StatusCodes.Status500InternalServerError);
                }
            }
            else
            {
                return BadRequest(ModelState);
            }
        }

        // PUT api/<ProductApiController>/5
        [HttpPut("{id}")]
        public IActionResult Put(int id, [FromBody] Product product)
        {
            //ssv
            if(id!=product.Id)
            {
                return BadRequest("id is not match");
            }
            else
            {
                //ssv
                if (ModelState.IsValid)
                {
                    //update
                    if(productRepository.Update(product))
                    {
                        return Ok(product);
                    }
                    else
                    {
                        return StatusCode(StatusCodes.Status500InternalServerError);
                    }
                }
                else
                {
                    return BadRequest(ModelState);
                }
            }
            }

        // DELETE api/<ProductApiController>/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var product = productRepository.Get(id);
                if (productRepository.Delete(product))
                {
                    return Ok();
                }
            return StatusCode(StatusCodes.Status404NotFound);

        }
      

    }
}
