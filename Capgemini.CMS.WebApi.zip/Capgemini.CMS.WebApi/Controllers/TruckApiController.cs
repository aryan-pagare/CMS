﻿using Capgemini.CMS.Entities.Models;
using Capgemini.CMS.Repositories.Products;
using Capgemini.CMS.Repositories.Trucks;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Capgemini.CMS.WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TruckApiController : ControllerBase
    {
        private readonly ITruckRepository truckRepository;

        public TruckApiController(ITruckRepository truckRepository)
        {
            this.truckRepository = truckRepository;
        }

        // GET: api/<TruckApiController>
        [HttpGet]
        public IEnumerable<Truck> Get()
        {
            var list = truckRepository.Get();
            return list;
        }

        // GET api/<TruckApiController>/5
        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            var product = truckRepository.Get(id);
            if (product == null)
            {
                return NotFound();
            }
            return Ok(product);
        }

        // POST api/<TruckApiController>
        [HttpPost]
        public IActionResult Post([FromBody] Truck truck)
        {
            if (ModelState.IsValid)
            {
                //repo.Add
                try
                {
                    if (truckRepository.Add(truck))
                    {
                        return Created("truck", truck);
                    }
                }
                catch (Exception ex)
                {
                    return Conflict();
                }
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
            else
            {
                return BadRequest(ModelState);
            }
        }

        // PUT api/<TruckApiController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/<TruckApiController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
