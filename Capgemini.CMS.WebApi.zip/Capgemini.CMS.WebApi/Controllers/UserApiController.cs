﻿using Capgemini.CMS.Entities.Models;
using Capgemini.CMS.Repositories.Products;
using Capgemini.CMS.Repositories.Users;
using Microsoft.AspNetCore.Mvc;


// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Capgemini.CMS.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserApiController : ControllerBase
    {
        private readonly IUserRepository userRepo;

        public UserApiController(IUserRepository userRepo)
        {
            this.userRepo = userRepo;
        }

        // GET: api/<UserApiController>
        [HttpGet]
        public IEnumerable<AspNetUser> Get()
        {
            var list = userRepo.Get();
            return list;
        }

       
        [HttpGet("{id}")]

        public IActionResult Get(string id)

                {

                    var order = userRepo.GetByStringId(id);

                    if (order == null)

                    {

                        return NotFound();

                    }

                    return Ok(order);

                }



        // POST api/<UserApiController>
        [HttpPost]
        public IActionResult Post([FromBody] AspNetUser user)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    if (userRepo.Add(user))
                    {
                        return Created("User", user);
                    }

                }

                catch (Exception ex)
                {
                    return Conflict(ex);
                }
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
            else
            {
                return BadRequest(ModelState);
            }
        }

        // PUT api/<UserApiController>/5
        [HttpPut("{id}")]
        public IActionResult Put(string id, [FromBody] AspNetUser usr)
        {
            

            if (id != usr.Id)
            {
                return BadRequest("id is not match");
            }
            else
            {
                //ssv
                if (ModelState.IsValid)
                {
                    //update
                    if (userRepo.Update(usr))
                    {
                        return Ok(usr);
                    }
                    else
                    {
                        return StatusCode(StatusCodes.Status500InternalServerError);
                    }
                }
                else
                {
                    return BadRequest(ModelState);
                }
            }

        }
            

// DELETE api/<UserApiController>/5
[HttpDelete("{id}")]
        public void Delete(int id)
        {
        }


        //[HttpGet("{searchUser}")]
        //public IActionResult Get(string searchUser)
        //{
        //    var product = userRepo.GetByName(searchUser);
        //    if (product == null)
        //    {
        //        return NotFound();
        //    }
        //    return Ok(product);
        //}

        
    
    }
}
