﻿using Capgemini.CMS.Entities.Models;
using Capgemini.CMS.Repositories.Warehouses;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Capgemini.CMS.WebApi.Controllers
{
    
    [Route("api/[controller]")]
    [ApiController]
    public class WarehouseApiController : ControllerBase
    {
        private readonly IWarehouseRepository wareHouseRepository;

        public WarehouseApiController(IWarehouseRepository wareHouseRepository)
        {
            this.wareHouseRepository = wareHouseRepository;
        }

        // GET: api/<WarehouseApiController>
        [HttpGet]
        public IEnumerable<Warehouse> Get()
        {
            var list = wareHouseRepository.Get();
            return list;
        }

        // GET api/<WarehouseApiController>/5
        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            var warehouse = wareHouseRepository.Get(id);
            if (warehouse == null)
            {
                return NotFound();
            }
            return Ok(warehouse);
        }

        // POST api/<WarehouseApiController>
        [HttpPost]
        public IActionResult Post([FromBody] Warehouse wareHouse)
        {
            if (ModelState.IsValid)
            {
                //repo.Add
                try
                {
                    if (wareHouseRepository.Add(wareHouse))
                    {
                        return Created("warehouse", wareHouse);
                    }
                }
                catch (Exception ex)
                {
                    return Conflict();
                }
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
            else
            {
                return BadRequest(ModelState);
            }
        }

        // PUT api/<WarehouseApiController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/<WarehouseApiController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
