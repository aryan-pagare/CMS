
using Capgemini.CMS.Entities.Models;
using Capgemini.CMS.Repositories.CargoOrders;
using Capgemini.CMS.Repositories.Products;
using Capgemini.CMS.Repositories.Trucks;
using Capgemini.CMS.Repositories.Users;
using Capgemini.CMS.Repositories.Warehouses;
using Capgemini.CMS.WebApi.Controllers;
using Microsoft.EntityFrameworkCore;

namespace Capgemini.CMS.WebApi
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.

            builder.Services.AddControllers();
            // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();
            builder.Services.AddControllers().AddNewtonsoftJson(

                options =>

                {

                    options.SerializerSettings.ReferenceLoopHandling =

                    Newtonsoft.Json.ReferenceLoopHandling.Ignore;

                });

            builder.Services.AddDbContext<CargoMsdbContext>
                (
                    options => options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection"))
                );

            builder.Services.AddScoped<IProductRepository, ProductServices>();
            builder.Services.AddScoped<ICargoOrderRepository, CargoOrderServices>();
            builder.Services.AddScoped<ITruckRepository, TruckServices>();
            builder.Services.AddScoped<IUserRepository, UserServices>();
            builder.Services.AddScoped<IWarehouseRepository, WarehouseServices>();  
            var app = builder.Build();


            


            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseHttpsRedirection();

            app.UseAuthorization();


            app.MapControllers();

            app.Run();
        }
    }
}
