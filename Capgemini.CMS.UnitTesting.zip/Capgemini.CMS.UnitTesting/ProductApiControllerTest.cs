﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Capgemini.CMS.WebApi.Controllers;
using Capgemini.CMS.Entities.Models;
using Capgemini.CMS.Repositories.Products;
using Moq;

namespace Capgemini.CMS.WebApi.Tests
{
    public class ProductApiControllerTests
    {
        private readonly Mock<IProductRepository> _mockProductRepository;
        private readonly ProductApiController _controller;

        public ProductApiControllerTests()
        {
            _mockProductRepository = new Mock<IProductRepository>();
            _controller = new ProductApiController(_mockProductRepository.Object);
        }

        //[Fact]
        //public void Get_ReturnsOkResult_WithListOfProducts()
        //{
        //    // Arrange
        //    var products = new List<Product>
        //    {
        //        new Product { Id = 1, Name = "Product1" , Description = "Test", UnitPrice = 20, Weight = 10}
        //        //new Product { Id = 2, Name = "Product2" }
        //    };
        //    _mockProductRepository.Setup(repo => repo.Get()).Returns(products);

        //    // Act
        //    var result = _controller.Get() as IEnumerable<Product>;

        //    // Assert
        //    Assert.NotNull(result);
        //    Assert.Equal(2, result.Count());
        //}

        [Fact]
        public void Get_ReturnsNotFoundResult_WhenProductNotFound()
        {
            // Arrange
            _mockProductRepository.Setup(repo => repo.Get(It.IsAny<int>())).Returns((Product)null);

            // Act
            var result = _controller.Get(1) as IActionResult;

            // Assert
            Assert.IsType<NotFoundResult>(result);
        }

        [Fact]
        public void Post_ReturnsCreatedResult_WhenProductIsValid()
        {
            // Arrange
            var product = new Product { Id = 1, Name = "Product1" };
            _mockProductRepository.Setup(repo => repo.Add(product)).Returns(true);

            // Act
            var result = _controller.Post(product) as IActionResult;

            // Assert
            var createdResult = Assert.IsType<CreatedResult>(result);
            Assert.Equal("product", createdResult.Location);
            Assert.Equal(product, createdResult.Value);
        }

        [Fact]
        public void Post_ReturnsBadRequest_WhenModelStateIsInvalid()
        {
            // Arrange
            _controller.ModelState.AddModelError("Name", "Required");
            var product = new Product { Id = 1, Name = "" };

            // Act
            var result = _controller.Post(product) as IActionResult;

            // Assert
            Assert.IsType<BadRequestObjectResult>(result);
        }

        [Fact]
        public void Put_ReturnsOkResult_WhenProductIsUpdated()
        {
            // Arrange
            var product = new Product { Id = 1, Name = "UpdatedProduct" };
            _mockProductRepository.Setup(repo => repo.Update(product)).Returns(true);

            // Act
            var result = _controller.Put(1, product) as IActionResult;

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal(product, okResult.Value);
        }

        [Fact]
        public void Put_ReturnsBadRequest_WhenIdDoesNotMatch()
        {
            // Arrange
            var product = new Product { Id = 2, Name = "Product" };

            // Act
            var result = _controller.Put(1, product) as IActionResult;

            // Assert
            Assert.IsType<BadRequestObjectResult>(result);
        }





    }
}