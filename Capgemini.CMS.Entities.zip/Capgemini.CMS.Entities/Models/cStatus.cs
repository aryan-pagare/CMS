﻿using System.Collections;

namespace Capgemini.CMS.Entities
{
    public enum cStatus
    {
        
        Pending,
        Delivered
    }

    public class CType
    {
        public static ArrayList cType = new ArrayList()
      {
          "General" , "Bulk"
      };
    }
}