﻿using System;
using System.Collections.Generic;

namespace Capgemini.CMS.Entities.Models;

public partial class Warehouse
{
    public int Id { get; set; }

    public string Name { get; set; } = null!;

    public string Address { get; set; } = null!;

    public virtual ICollection<CargoOrder> CargoOrderDestWs { get; set; } = new List<CargoOrder>();

    public virtual ICollection<CargoOrder> CargoOrderSourceWs { get; set; } = new List<CargoOrder>();
}
