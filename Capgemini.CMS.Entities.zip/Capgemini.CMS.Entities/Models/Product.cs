﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Capgemini.CMS.Entities.Models;

public partial class Product
{
    public int Id { get; set; }

    public string Name { get; set; } = null!;

    public string Description { get; set; } = null!;
    [Required]
    [Range(10,1000)]
    public decimal UnitPrice { get; set; }

    [Required]
    [Range(1,100)]
    public decimal Weight { get; set; }

    public virtual ICollection<CargoOrderDetail> CargoOrderDetails { get; set; } = new List<CargoOrderDetail>();

    public virtual ICollection<CargoOrder> CargoOrders { get; set; } = new List<CargoOrder>();
}
