﻿using System;
using System.Collections.Generic;

namespace Capgemini.CMS.Entities.Models;

public partial class CargoOrder
{
    public int Id { get; set; }

    public DateOnly OrderDate { get; set; }

    public int Status { get; set; }

    public string?CargoType { get; set; } 

    public string? UserId { get; set; }

    public int SourceWid { get; set; }

    public int DestWid { get; set; }

    public int TruckId { get; set; }

    public int? ProductId { get; set; }

    public virtual ICollection<CargoOrderDetail> CargoOrderDetails { get; set; } = new List<CargoOrderDetail>();

    public virtual Warehouse? DestW { get; set; } 

    public virtual Product? Product { get; set; }

    public virtual Warehouse? SourceW { get; set; } 

    public virtual Truck? Truck { get; set; } 

    public virtual AspNetUser? User { get; set; } 
}
