﻿using System;
using System.Collections.Generic;

namespace Capgemini.CMS.Entities.Models;

public partial class Truck
{
    public int Id { get; set; }

    public string TruckNo { get; set; } = null!;

    public virtual ICollection<CargoOrder> CargoOrders { get; set; } = new List<CargoOrder>();
}
