﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capgemini.CMS.Entities.ViewModels
{
    public class ProductWithQuantity
    {
        public int Id { get; set; }

        [Required]
        public string Name { get; set; } = null!;

        [Required]
        public string Description { get; set; } = null!;

        [Required]
        [Range(10,100 )]
        public decimal UnitPrice { get; set; }

        [Required]
        [Range(0,100)]
        public decimal Weight { get; set; }


        
        public int Quantity { get; set; }
    }
}
