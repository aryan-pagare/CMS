﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capgemini.CMS.Entities.ViewModels
{
    public class SearchUserViewModel
    {
        public string Email { get; set; }

    }
}
