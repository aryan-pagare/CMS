﻿using Capgemini.CMS.Entities.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capgemini.CMS.Entities.ViewModels
{
    public class CargoOrderViewModel
    {
        public List<ProductWithQuantity> List {  get; set; }

        [Required]
        public int SourceWarehouseId { get; set; }
        [Required]
        public int DestinationWarehouseId { get; set; }

        [Required]
        public int TruckId { get; set; }

        [Required]

        public string CargoType { get; set; }

        

        public string UserId { get; set; }
      
    }
}
