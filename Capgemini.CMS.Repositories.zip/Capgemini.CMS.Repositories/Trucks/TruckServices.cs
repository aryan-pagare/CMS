﻿using Capgemini.CMS.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capgemini.CMS.Repositories.Trucks
{
    public class TruckServices : ITruckRepository
    {
        private readonly CargoMsdbContext context;

        public TruckServices(CargoMsdbContext context)
        {
            this.context = context;
        }
        public bool Add(Truck entity)
        {
            context.Add(entity);
            int changes = context.SaveChanges();
            return changes > 0;
        }

        public bool Delete(Truck entity)
        {
            throw new NotImplementedException();
        }

        public Truck Get(int id)
        {
            var order = context.Trucks.FirstOrDefault(x => x.Id == Convert.ToInt32(id));
            return order;
        }

        public List<Truck> Get()
        {
            var order = context.Trucks.ToList();
            return order;
        }

        public bool Update(Truck entity)
        {
            throw new NotImplementedException();
        }
    }
}
