﻿using Capgemini.CMS.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capgemini.CMS.Repositories.Trucks
{
    public  interface ITruckRepository : IRepository<Truck>
    {
    }
}
