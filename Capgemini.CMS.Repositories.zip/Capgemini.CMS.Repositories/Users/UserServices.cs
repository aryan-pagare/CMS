﻿using Capgemini.CMS.Entities.Models;
using Capgemini.CMS.Exceptions;
using Capgemini.CMS.Repositories.Products;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capgemini.CMS.Repositories.Users
{
    public class UserServices : IUserRepository
    {

        private readonly CargoMsdbContext context;

        public UserServices(CargoMsdbContext context)
        {
            this.context = context;
        }

        public AspNetUser Get(string id)
        {
            var usr = context.AspNetUsers.FirstOrDefault(u => u.Id == id);
            if (usr == null)
            {
                throw new CmsException("Configure request not found");
            }
            return usr;
        }

        public AspNetUser Get(int id)
        {
            throw new NotImplementedException();
        }

        bool IRepository<AspNetUser>.Add(AspNetUser entity)
        {
            if (context.AspNetUsers.Any(n => n.Email == entity.Email))
            {
                throw new CmsException("User Already Exists");
            }
            context.Add(entity);
            int recordsAffected = context.SaveChanges();
            return recordsAffected > 0;
        }

        bool IRepository<AspNetUser>.Delete(AspNetUser entity)
        {
            throw new NotImplementedException();
        }

      

        List<AspNetUser> IRepository<AspNetUser>.Get()
        {

            var usr = context.AspNetUsers.ToList();
            return usr;
        }

        public bool Update(AspNetUser entity)
        {



            AspNetUser usr = context.AspNetUsers.Where(u => u.Id == entity.Id).FirstOrDefault();
            if(usr == null)
            {
                throw new CmsException("usr not found to be updated");
            }

            usr.Email = entity.Email;
            usr.UserName = entity.UserName;
            usr.PhoneNumber = entity.PhoneNumber;
            usr.PasswordHash = entity.PasswordHash;
            int recordsAffected = context.SaveChanges();
            return recordsAffected > 0;

        }

        public AspNetUser GetByStringId(string id)
        {
            var usr = context.AspNetUsers.FirstOrDefault(u => u.Id == id);
            if (usr == null)
            {
                throw new CmsException("Configure request not found");
            }
            return usr;
        }

        AspNetUser IUserRepository.GetByName(string name)
        {
            var usr = context.AspNetUsers.FirstOrDefault(x => x.Email == name);
            return usr;
        }
    }
    }

