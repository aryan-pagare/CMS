﻿using Capgemini.CMS.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capgemini.CMS.Repositories.Users
{
    public interface IUserRepository : IRepository<AspNetUser>
    {
        AspNetUser Get(string id);
        AspNetUser GetByName(string name);

        AspNetUser GetByStringId(string name);

        
    }
}
