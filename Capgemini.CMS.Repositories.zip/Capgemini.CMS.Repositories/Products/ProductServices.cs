﻿using Capgemini.CMS.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capgemini.CMS.Repositories.Products
{
    public class ProductServices : IProductRepository
    {
        private readonly CargoMsdbContext context;

        public ProductServices(CargoMsdbContext context)
        {
            this.context = context;
        }

        public bool Add(Product entity)
        {
            context.Add(entity);
            int changes = context.SaveChanges();
            return changes > 0;
        }

        public bool Delete(Product entity)
        {
            context.Remove(entity);
            return context.SaveChanges() > 0;
        }

        public Product Get(int id)
        {
            var product = context.Products.FirstOrDefault(x => x.Id == id);
            return product;
        }
      
        

        public List<Product> Get()
        {
            var product = context.Products.ToList();
            return product;
        }

        public bool Update(Product entity)
        {
            context.Update(entity);
            return context.SaveChanges() > 0;   
        }

        Product IProductRepository.GetByName(string name)
        {
            var product = context.Products.FirstOrDefault(x => x.Name == name);
            return product;
        }
    }
}
