﻿using Capgemini.CMS.Entities.Models;
using Capgemini.CMS.Entities.ViewModels;
using Capgemini.CMS.Exceptions;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capgemini.CMS.Repositories.CargoOrders
{
    public class CargoOrderServices : ICargoOrderRepository
    {
        private readonly CargoMsdbContext context;

        public CargoOrderServices(CargoMsdbContext context)
        {
            this.context = context;
        }

        public bool Add(CargoOrder entity)
        {
            try
            {
                context.CargoOrders.Add(entity);
                return context.SaveChanges() > 0;
                throw new CmsException("Cargo Order Not Added");
            }
            catch (Exception ex) { 
                return false;
            }

            
        }

        public bool AddCart(CargoOrderViewModel viewModel)
        {
            try
            {
                context.CargoOrders.Add(new CargoOrder
                {
                    CargoType = viewModel.CargoType,
                    SourceWid = viewModel.SourceWarehouseId,
                    DestWid = viewModel.DestinationWarehouseId,
                    TruckId = viewModel.TruckId,
                    UserId = viewModel.UserId,
                
            });
                return context.SaveChanges() > 0;
                throw new CmsException("New order is not added to cart");
            }
            catch(Exception ex)
            {
                throw ex;
            }
            //cargoorder add
            

            //foreach list, cargoorderdetails-> add
       /*     foreach (var item in viewModel.List)
            {
                context.CargoOrderDetails.Add(new CargoOrderDetail
                {
                    Quantity = item.Quantity,
                    TotalPrice = item.UnitPrice * item.Weight                     
                });
            }
       */
            
            
        }

        public bool Delete(CargoOrder entity)
        {

            try
            {
                context.Remove(entity);
                return context.SaveChanges() > 0;
                throw new CmsException("Cargo Order not deleted");
            }
            catch (Exception Ex) {
                throw Ex;
            }
            
        }

        public CargoOrder Get(int id)
        {
           var cargoOrder = context.CargoOrders.FirstOrDefault(x => x.Id == id);
            return cargoOrder;
        }

        public List<CargoOrder> Get()
        {

            var order = context.CargoOrders.Include(m => m.DestW).ToList();
            return order;
        }

        public bool Update(CargoOrder entity)
        {
            try
            {
                var ord = context.CargoOrders.Find(entity.Id);
                if (ord != null)
                {
                    ord.CargoType = entity.CargoType;
                    ord.Status = entity.Status;
                    int recordsAffected = context.SaveChanges();
                    return recordsAffected > 0;
                    
                }
                else
                    throw new CmsException("Not Updated");
            }
            catch (Exception ex)
            {
                return false;
            }
         

        }
    }
}
