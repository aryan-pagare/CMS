﻿using Capgemini.CMS.Entities.Models;
using Capgemini.CMS.Entities.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capgemini.CMS.Repositories.CargoOrders
{
    public interface ICargoOrderRepository : IRepository<CargoOrder>
    {
        bool AddCart(CargoOrderViewModel viewModel);
    }
}
