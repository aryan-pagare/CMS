﻿using Capgemini.CMS.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capgemini.CMS.Repositories.Warehouses
{
    public class WarehouseServices : IWarehouseRepository
    {
        private readonly CargoMsdbContext context;

        public WarehouseServices(CargoMsdbContext context)
        {
            this.context = context;
        }

        public bool Add(Warehouse entity)
        {
            context.Add(entity);
            int changes = context.SaveChanges();
            return changes > 0;
        }

        public bool Delete(Warehouse entity)
        {
            throw new NotImplementedException();
        }

        public Warehouse Get(int id)
        {
            var warehouse = context.Warehouses.FirstOrDefault(x => x.Id == Convert.ToInt32(id));
            return warehouse;
        }

        public List<Warehouse> Get()
        {
            var wareHouse = context.Warehouses.ToList();
            return wareHouse;
        }

        public bool Update(Warehouse entity)
        {
            throw new NotImplementedException();
        }
    }
}
