﻿using Capgemini.CMS.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capgemini.CMS.Repositories.Warehouses
{
    public  interface IWarehouseRepository : IRepository<Warehouse>
    {
    }
}
