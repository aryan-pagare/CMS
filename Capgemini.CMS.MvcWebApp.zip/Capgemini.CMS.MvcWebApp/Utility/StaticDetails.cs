﻿namespace Capgemini.CMS.MvcWebApp.Utility
{
    public class StaticDetails
    {
        public const string Role_Cust = "Customer";
        public const string Role_Employee = "Employee";
        public const string Role_Admin = "Admin";
    }
}
