﻿using System;
using System.Collections.Generic;

namespace Capgemini.CMS.MvcWebApp.Models;

public partial class CargoOrder
{
    public int Id { get; set; }

    public DateOnly OrderDate { get; set; }

    public int Status { get; set; }

    public string CargoType { get; set; } = null!;

    public string UserId { get; set; } = null!;

    public int ProductId { get; set; }

    public int SourceWid { get; set; }

    public int DestWid { get; set; }

    public int TruckId { get; set; }

    public virtual ICollection<CargoOrderDetail> CargoOrderDetails { get; set; } = new List<CargoOrderDetail>();

    public virtual Warehouse DestW { get; set; } = null!;

    public virtual Product Product { get; set; } = null!;

    public virtual Warehouse SourceW { get; set; } = null!;

    public virtual Truck Truck { get; set; } = null!;

    public virtual AspNetUser User { get; set; } = null!;
}
