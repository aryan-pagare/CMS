﻿using Microsoft.AspNetCore.Identity;

namespace Capgemini.CMS.MvcWebApp.Models
{
    public class ApplicationUser : IdentityUser
    {
    }
}
