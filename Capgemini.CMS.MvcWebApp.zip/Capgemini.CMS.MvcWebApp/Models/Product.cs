﻿using System;
using System.Collections.Generic;

namespace Capgemini.CMS.MvcWebApp.Models;

public partial class Product
{
    public int Id { get; set; }

    public string Name { get; set; } = null!;

    public string Description { get; set; } = null!;

    public decimal UnitPrice { get; set; }

    public decimal Weight { get; set; }

    public virtual ICollection<CargoOrderDetail> CargoOrderDetails { get; set; } = new List<CargoOrderDetail>();

    public virtual ICollection<CargoOrder> CargoOrders { get; set; } = new List<CargoOrder>();
}
