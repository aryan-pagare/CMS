﻿using Capgemini.CMS.Entities;
using Capgemini.CMS.Entities.Models;
using Capgemini.CMS.Entities.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json;
using NuGet.Packaging.Signing;
using System.Collections;
using System.Collections.Generic;
using System.Security.Policy;

namespace Capgemini.CMS.MvcWebApp.Controllers
{
    public class CargoOrderController : Controller
    {
        string apiUrl;
        private readonly UserManager<IdentityUser> userManager;

        public CargoOrderController(IConfiguration config, UserManager<IdentityUser> userManager)
        {
            apiUrl = config["ApiUrl"];
            this.userManager = userManager;
        }


        

        // GET: CargoOrderController
        public ActionResult Index()
        {

            IEnumerable<CargoOrder> cargoOrder = null;
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(apiUrl);
                
                var responseTask = client.GetAsync("cargoorderapi");
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)

                {
                    var readTask = result.Content.ReadAsAsync<IList<CargoOrder>>();
                    readTask.Wait();
                    cargoOrder = readTask.Result;
                }
                else
                {
                    //log response status here..
                    cargoOrder = Enumerable.Empty<CargoOrder>();
                    ViewBag.Message = "API call failed";
                    //ModelState.AddModelError(string.Empty, "API error.");
                }
                
                return View(cargoOrder);
            }
         
        }

        [HttpGet]
        public ActionResult Cart()
        {
            var cartList = JsonConvert.DeserializeObject<List<ProductWithQuantity>>
                 (HttpContext.Session.GetString("cart"));

            //api cotroller warehouse -> get> list
            IEnumerable<Warehouse> warehouses = null;
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(apiUrl);

                var responseTask = client.GetAsync("warehouseapi");
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)

                {
                    var readTask = result.Content.ReadAsAsync<IList<Warehouse>>();
                    readTask.Wait();
                    warehouses = readTask.Result;
                }
                else
                {
                    warehouses = Enumerable.Empty<Warehouse>();
                    ViewBag.Message = "API call failed";
                }
            }
            


            //For Truck
            IEnumerable<Truck> trucks = null;
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(apiUrl);

                var responseTask = client.GetAsync("truckapi");
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)

                {
                    var readTask = result.Content.ReadAsAsync<IList<Truck>>();
                    readTask.Wait();
                    trucks = readTask.Result;
                }
                else
                {
                    trucks = Enumerable.Empty<Truck>();
                    ViewBag.Message = "API call failed";
                }
            }

            //ForCargoType
           

            CargoOrderViewModel viewModel = new CargoOrderViewModel
            {
                List = cartList                
            };
          
            ViewBag.Trucks = new SelectList(trucks, "Id", "TruckNo");
            ViewBag.Warehouses = new SelectList(warehouses, "Id", "Name");
            ViewBag.cType = new SelectList(CType.cType);
            return View(viewModel);
        }
      
        [HttpPost]
        public ActionResult Cart(CargoOrderViewModel viewModel)
        {
            var list = JsonConvert.DeserializeObject<List<ProductWithQuantity>>
                    (HttpContext.Session.GetString("cart"));

            viewModel.List = list;
            viewModel.UserId = userManager.GetUserId(User);
            
            //viewModel.CargoType = Entities.cType.General;
            //api call C, AM


            //cargoorderapi -> Post

            //We have to change inthis action.

            // for testing i used product       change this product to viewmodel data.
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(apiUrl);

                var responseTask = client.PostAsJsonAsync("cargoorderapi", viewModel);
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    ViewData["Message"] = $"Order Successfully Added,{userManager.NormalizeName}";

                    return RedirectToAction(nameof(Index));
                }
                
                
                //return View(viewModel);
            }
            return RedirectToAction(nameof(Index));
        }

        

        // GET: CargoOrderController/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: CargoOrderController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: CargoOrderController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: CargoOrderController/Edit/5
        public ActionResult Edit(int id)
        {
            {

                CargoOrder co = null;

                using (var client = new HttpClient())
                {

                    client.BaseAddress = new Uri(apiUrl);

                    var responseTask = client.GetAsync($"cargoorderapi/{id}");

                    responseTask.Wait();

                    var result = responseTask.Result;

                    if (result.IsSuccessStatusCode)

                    {

                        var readTask = result.Content.ReadAsAsync<CargoOrder>();

                        readTask.Wait();

                        co = readTask.Result;

                    }

                    else

                    {

                        ModelState.AddModelError(string.Empty, "API call failed");

                        return View(co);

                        // Handle API call failure, perhaps redirect or show an error message

                    }

                }

                ViewBag.cType = new SelectList(CType.cType);

                return View(co);

            }
        }

        // POST: CargoOrderController/Edit/5
        [Authorize(Roles = "Employee,Admin")]
        [HttpPost]
        [HttpPut]
        [ValidateAntiForgeryToken]
        public ActionResult Edited(int id, CargoOrder co)
        {

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(apiUrl);
                var responseTask = client.PutAsJsonAsync($"cargoorderapi/{id}", co);
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    ViewBag.Success = "Cargo Updated Successfully";
                }
                else
                {
                    ModelState.AddModelError(string.Empty, "API call failed");
                }
            }
            return Redirect(nameof(Index));

        }

        // GET: CargoOrderController/Delete/5
        public ActionResult Delete(int id)
        {
            CargoOrder order = null;
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(apiUrl);
                var responseTask = client.GetAsync($"cargoorderapi/{id}");
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<CargoOrder>();
                    readTask.Wait();
                    order = readTask.Result;
                }
                else
                {
                    order = null;
                    ViewBag.Message = "Api Call Failed";
                }
            }
            ViewBag.Message = "Deleted Successfull";
            return View(order);
        }

        // POST: CargoOrderController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, CargoOrder order)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(apiUrl);

                // Send a DELETE request to the API
                var responseTask = client.DeleteAsync($"cargoorderapi/{id}");
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    ViewBag.Deleted = "Product Deleted";
                    return RedirectToAction(nameof(Index));
                }
                else
                {
                    // Log the response status and show a failure message
                    ModelState.AddModelError(string.Empty, "Api call failed");
                    ViewBag.Message = "Failed to delete the product. Please try again.";
                    return View();
                }
            }
        }


        //Get:Updating cargo type
        public ActionResult Update()
        {
            
        return View(); 
        }
        [HttpPost]
        public ActionResult Update(string name)
        {
            CType.cType.Add(name);

            return View();
        }

        [Authorize(Roles = "Customer")]
        [HttpPost]
        public ActionResult OrderPlaced(CargoOrderViewModel viewModel)
        {
            var list = JsonConvert.DeserializeObject<List<ProductWithQuantity>>
                    (HttpContext.Session.GetString("cart"));

            viewModel.List = list;
            viewModel.UserId = userManager.GetUserId(User);

            decimal TotalPrice = 0;
            int TotalItems = 0;
            //foreach list, cargoorderdetails-> add
            foreach (ProductWithQuantity i in viewModel.List)
            {
                TotalPrice += i.UnitPrice * i.Quantity;
                TotalItems += i.Quantity;


            }



            CargoOrderDetail order = new CargoOrderDetail
            {
                TotalPrice = TotalPrice,
                Quantity = TotalItems
                 

            };



            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(apiUrl);

                var responseTask = client.PostAsJsonAsync("cargoorderapi", viewModel);
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    ViewData["Message"] = "Order Created";

                    return View(order);
                }
                ModelState.AddModelError(string.Empty, "Api call failed");
        
            }
            return Redirect(nameof(Index));

        }

        // GET: CargoOrderController
        public ActionResult SearchById()
        {

            IEnumerable<CargoOrder> cargoOrder = null;
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(apiUrl);

                var responseTask = client.GetAsync("cargoorderapi");
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)

                {
                    var readTask = result.Content.ReadAsAsync<IList<CargoOrder>>();
                    readTask.Wait();
                    cargoOrder = readTask.Result;
                }
                else
                {
                    //log response status here..
                    cargoOrder = Enumerable.Empty<CargoOrder>();
                    ViewBag.Message = "API call failed";
                    //ModelState.AddModelError(string.Empty, "API error.");
                }
                return View(cargoOrder);
            }

        }


        //Search 
        [Authorize(Roles = "Employee , Admin")]
        public ActionResult Search(int searchOrder)
        {
            IEnumerable<CargoOrder> ord = null;

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(apiUrl);

                var responseTask = client.GetAsync("cargoorderapi");
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)

                {
                    var readTask = result.Content.ReadAsAsync<IList<CargoOrder>>();
                    readTask.Wait();
                    ord = readTask.Result;
                }
                else
                {
                    //log response status here..
                    ord = Enumerable.Empty<CargoOrder>();
                    ViewBag.Message = "API call failed";

                }
            }

            var find = ord.FirstOrDefault(o => o.Id == searchOrder);
            if (find != null)
                return View(find);
            else {
                ViewBag.Message = "Not found";
                    
            }
            
                
            return View(find);
        }

        //UpdateOrder

        public ActionResult UpdateOrder()
        {

            IEnumerable<CargoOrder> cargoOrder = null;
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(apiUrl);

                var responseTask = client.GetAsync("cargoorderapi");
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)

                {
                    var readTask = result.Content.ReadAsAsync<IList<CargoOrder>>();
                    readTask.Wait();
                    cargoOrder = readTask.Result;
                }
                else
                {
                    //log response status here..
                    cargoOrder = Enumerable.Empty<CargoOrder>();
                    ViewBag.Message = "API call failed";
                    //ModelState.AddModelError(string.Empty, "API error.");
                }
                return View(cargoOrder);
            }

            // SearchByUserId

        }





        

    }
}
