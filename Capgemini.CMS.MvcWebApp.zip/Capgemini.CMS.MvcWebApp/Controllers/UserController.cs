﻿using Capgemini.CMS.Entities.Models;
using Capgemini.CMS.Entities.ViewModels;

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Capgemini.CMS.MvcWebApp.Controllers
{
    public class UserController : Controller
    {
        // GET: UserController

        string apiUrl;
        public UserController(IConfiguration config)
        {
            apiUrl = config["ApiUrl"];

        }
        public ActionResult Index()
        {
            {
                IEnumerable<AspNetUser> users = null;
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri(apiUrl);

                    var responseTask = client.GetAsync("userapi");
                    responseTask.Wait();

                    var result = responseTask.Result;
                    if (result.IsSuccessStatusCode)

                    {
                        var readTask = result.Content.ReadAsAsync<IList<AspNetUser>>();
                        readTask.Wait();
                        users = readTask.Result;
                    }
                    else
                    {
                        //log response status here..
                        users = Enumerable.Empty<AspNetUser>();
                        ViewBag.Message = "API call failed";

                    }
                    return View(users);
                }
            }

        }

        // GET: UserController/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: UserController/Create
        public ActionResult Create()
        {
            return LocalRedirect("/Identity/Account/Register");
        }

        // POST: UserController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: UserController/Edit/5
        public ActionResult Edit(string id)
        {
            AspNetUser usr = null;

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(apiUrl);
                var responseTask = client.GetAsync($"userapi/{id}");
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<AspNetUser>();
                    readTask.Wait();
                    usr = readTask.Result;
                }
                else
                {
                    ModelState.AddModelError(string.Empty, "API call failed");
                    return View(usr);
                    // Handle API call failure, perhaps redirect or show an error message
                }
            }

            return View(usr);
        }

        [Authorize(Roles = "Admin")]
        // POST: UserController/Edit/5
        [HttpPost]
        [HttpPut]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(AspNetUser usr)
        {
            string id = usr.Id;
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(apiUrl);
                var responseTask = client.PutAsJsonAsync($"userapi/{id}", usr);
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                   // TempData["success"] = "Employee Updated Successfully";
                    ViewBag.Edited = $"{usr.Email} Updated";
                    return RedirectToAction(nameof(Index), usr);

                }
                else
                {
                    ModelState.AddModelError(string.Empty, "API call failed");
                    return View(usr);
                    // Handle API call failure, perhaps redirect or show an error message
                }
            }
        



        }

        // GET: UserController/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: UserController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        public ActionResult Search(string searchUser)
        {
            IEnumerable<AspNetUser> usr = null;

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(apiUrl);

                var responseTask = client.GetAsync("userapi");
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)

                {
                    var readTask = result.Content.ReadAsAsync<IList<AspNetUser>>();
                    readTask.Wait();
                    usr = readTask.Result;
                }
                else
                {
                    //log response status here..
                    usr = Enumerable.Empty<AspNetUser>();
                    ViewBag.Message = "API call failed";

                }
            }
            var find = usr.FirstOrDefault(u => u.UserName == searchUser);
            if (find != null)
                return View(find);
            else
                ViewBag.Message = "Not found";
            return Redirect(nameof(Index));
        }
    }

}
