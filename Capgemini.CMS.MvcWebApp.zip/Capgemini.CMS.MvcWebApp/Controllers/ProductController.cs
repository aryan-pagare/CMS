﻿using Capgemini.CMS.Entities.Models;
using Capgemini.CMS.Entities.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;

namespace Capgemini.CMS.MvcWebApp.Controllers
{
    public class ProductController : Controller
    {
        string apiUrl;
        public ProductController(IConfiguration config)
        {
            apiUrl = config["ApiUrl"];
        }
        // GET: ProductController
        public ActionResult Index()
        {
            IEnumerable<Product> products = null;
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(apiUrl);
                //client.DefaultRequestHeaders.Authorization =
                //new AuthenticationHeaderValue("Bearer", HttpContent
                //HTTP GET
                var responseTask = client.GetAsync("productapi");
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)

                {
                    var readTask = result.Content.ReadAsAsync<IList<Product>>();
                    readTask.Wait();
                    products = readTask.Result;
                }
                else
                {
                    //log response status here..
                    products = Enumerable.Empty<Product>();
                    ViewBag.Message = "API call failed";
                    //ModelState.AddModelError(string.Empty, "API error.");
                }
                return View(products);
            }
        }

        // GET: ProductController/Details/5
        [HttpGet]
        public ActionResult Details(int id)
        {
            Product product = null;
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(apiUrl);

                var responseTask = client.GetAsync($"productapi/{id}");
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<Product>();
                    readTask.Wait();
                    product = readTask.Result;
                }
                else
                {
                    //log response status here..
                    product = new Product();
                    ViewBag.Message = "API call failed";

                }
            }
            ProductWithQuantity product1 = new ProductWithQuantity
            {
                Id = product.Id,
                Name = product.Name,
                Description = product.Description,
                UnitPrice = product.UnitPrice,
                Weight = product.Weight,

            };
            return View(product1);
        }

   

        //POST: ProductController/Details
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Details(int id, ProductWithQuantity product)
        {
            List<ProductWithQuantity> list;

            if (HttpContext.Session.GetString("cart") == null)
            {
                list = new List<ProductWithQuantity>
                {
                    product
                };
            }
            else
            {
                list = JsonConvert.DeserializeObject<List<ProductWithQuantity>>
                    (HttpContext.Session.GetString("cart"));
                list.Add(product);
            }
            
            HttpContext.Session.SetString("cart", JsonConvert.SerializeObject(list));
            ViewBag.Added = $"{product.Name}added to cart successfully";
            return RedirectToAction("Index");
        }


        public ActionResult Create()
        {
            return View();
        }

        // POST: ProductController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Product product)
        {

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(apiUrl);

                var responseTask = client.PostAsJsonAsync("productapi", product);
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    ViewData["Message"] = "Product Created";

                    return RedirectToAction(nameof(Index), product);
                }
                ModelState.AddModelError(string.Empty, "Api call failed");
                return View(product);
            }

        }

        // GET: ProductController/Edit/5
        public ActionResult Edit(int id)
        {
            Product prod = null;

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(apiUrl);
                var responseTask = client.GetAsync($"productapi/{id}");
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<Product>();
                    readTask.Wait();
                    prod = readTask.Result;
                }
                else
                {
                    ModelState.AddModelError(string.Empty, "API call failed");
                    return View(prod);
                    // Handle API call failure, perhaps redirect or show an error message
                }
            }

            return View(prod);
        }

        // POST: ProductController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]

        public ActionResult Edit(int id, Product product)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(apiUrl);

                var responseTask = client.PutAsJsonAsync($"productapi/{id}", product);
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    ViewData["Message"] = "Product Updated";

                    return RedirectToAction(nameof(Index), product);
                }   
                ModelState.AddModelError(string.Empty, "Api call failed");
                return View(product);
            }


        }

        // GET: ProductController/Delete/5
        public ActionResult Delete(int id)
        {
            Product product = null;
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(apiUrl);
                var responseTask = client.GetAsync($"productapi/{id}");
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<Product>();
                    readTask.Wait();
                    product = readTask.Result;
                }
                else
                {
                    product = null;
                    ViewBag.Message = "Api Call Failed";
                }
            }
            return View(product);


        }

        // POST: ProductController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, Product product)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(apiUrl);

                // Send a DELETE request to the API
                var responseTask = client.DeleteAsync($"productapi/{id}");
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    ViewData["Message"] = "Product Deleted";
                    return RedirectToAction(nameof(Index));
                }
                else
                {
                    // Log the response status and show a failure message
                    ModelState.AddModelError(string.Empty, "Api call failed");
                    ViewBag.Message = "Failed to delete the product. Please try again.";
                    return View();
                }
            }
        }
    }
}
